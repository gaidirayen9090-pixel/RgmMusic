let player;
let isPlaying = false;

const canvas = document.getElementById('waveCanvas');
const ctx = canvas.getContext('2d');
canvas.width = canvas.offsetWidth;
canvas.height = canvas.offsetHeight;

// YouTube Player
function onYouTubeIframeAPIReady() {
    player = new YT.Player('player', {
        height: '360',
        width: '640',
        videoId: 'EDxb1X1h--Y',
        playerVars: { 'autoplay': 0, 'controls': 0 },
        events: { 'onReady': onPlayerReady }
    });
}

function onPlayerReady(event) {
    drawWave();
}

document.getElementById('playBtn').addEventListener('click', ()=>{
    if(!isPlaying){
        player.playVideo();
        isPlaying=true;
    }else{
        player.pauseVideo();
        isPlaying=false;
    }
});

// Simple wave animation
function drawWave(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    let time = new Date().getTime() * 0.002;
    ctx.beginPath();
    for(let x=0;x<canvas.width;x++){
        let y = canvas.height/2 + Math.sin(x*0.02 + time)*30;
        ctx.lineTo(x,y);
    }
    ctx.strokeStyle="#f39c12";
    ctx.lineWidth=2;
    ctx.stroke();
    requestAnimationFrame(drawWave);
}